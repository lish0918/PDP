#include <stdio.h>

#include "print_array.h"

void print_array(int *arr, int N) {
	for (int i=0; i<N; i++) {
		printf("%d ", arr[i]);
	}
	printf("\n");
}
