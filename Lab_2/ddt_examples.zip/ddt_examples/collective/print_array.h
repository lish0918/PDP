#ifndef PRINT_ARRAY_H_
#define PRINT_ARRAY_H_

/**
 * Print the content of arr to stdout
 * @param arr Array to print
 * @param N Length of arr
 */
void print_array(int *arr, int N);

#endif
