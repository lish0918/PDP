/**
 * Demo program for MPI_collective
 */

#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>

#include "print_array.h"

int main(int argc, char **argv) {
	MPI_Init(&argc, &argv);

        const int root=0;
	int rank, num_proc;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &num_proc);
	int local_size = 10;
	int local_iter = 0;
	int i,j;
	int *send_buf = malloc(num_proc*local_size*sizeof(int));
	int *iter_buf = malloc(num_proc*sizeof(int));
	int *recv_buf = calloc(local_size,sizeof(int));
	
	if(rank == root) {

	   for (i=0; i<num_proc; i++) {
	           iter_buf[i] = 100*(i+1); 
	           for (j=0; j<local_size; j++) {
		       send_buf[i*local_size+j] = 1*(i+1);
		   }
	   }
	   /*printf("proc %d: local_size: %d \n", rank,local_size);
	   print_array(send_buf, num_proc*local_size);
	   print_array(iter_buf, num_proc);*/
	}
	MPI_Bcast(&local_size, 1, MPI_INT, root, MPI_COMM_WORLD);
        /*printf("proc %d: local_size: %d \n", rank,local_size);*/
	MPI_Scatter(iter_buf, 1, MPI_INT, &local_iter, 1, MPI_INT, root, MPI_COMM_WORLD);
		/*printf("proc %d: local_iter: %d \n", rank,local_iter);*/	 
	MPI_Scatter(send_buf, local_size, MPI_INT, recv_buf, local_size, MPI_INT, root, MPI_COMM_WORLD);	 
        /*print_array(recv_buf, local_size);*/

/* Do local work */
	for (i=0; i<local_iter; i++){
		for (j=0; j<local_size; j++){
			recv_buf[j] = recv_buf[j]+1;
		}
	}
	/*printf("proc %d: recv_buf before gather: ", rank);*/
	/*print_array(recv_buf, local_size);*/
	
/* End do local work */	 
	MPI_Gather(recv_buf, local_size, MPI_INT, send_buf, local_size, MPI_INT, root, MPI_COMM_WORLD);
	print_array(send_buf, num_proc*local_size);
	int global_buf = 0;
	MPI_Reduce(recv_buf, &global_buf, 1, MPI_INT, MPI_MAX, root, MPI_COMM_WORLD);	
        /*printf("Reduce: proc %d: global_buf: %d \n", rank,global_buf);*/
	MPI_Allreduce(recv_buf, &global_buf, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);	
        /*printf("Allreduce: proc %d: global_buf: %d \n", rank,global_buf);*/
	
	free(send_buf);
	free(recv_buf);
	free(iter_buf);
	MPI_Finalize();
	return 0;
}
